2024.02.26

=============================================
* rom file infomation
- file name : lpu237_5_22_0_1.rom.
- including firmware :
	index 0) For lpu237, MMD1100 & Magtek delta asic( nickname : ganymede ), v5.22.0.1
- update condition : a device' version is less then equal this rom' firmware version.

=============================================
* rom 파일 정보
- 파일 이름 : lpu237_5_22_0_1.rom
- 포함된 펨웨어 :
	색인1 에 있는 펨웨어) lpu237, MMD1100 와 Magtek delta asic 동시 지원하는 보드용.(  별칭 : ganymede ), v5.22.0.1

- 펨웨어 업데이트 가능 조건 : 장비의 현재 버전이 rom의 펨웨어의 버전보다 낮거나 같다.
